#ifndef CRC32_H
#define CRC32_H
 
extern unsigned int crc32(unsigned char *buf, int len);

#endif
